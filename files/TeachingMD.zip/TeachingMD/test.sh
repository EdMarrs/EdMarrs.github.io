cd /mnt/d/Users/edmar/Documents/Teaching/Teaching/
javac HelloWorld.java
java HelloWorld