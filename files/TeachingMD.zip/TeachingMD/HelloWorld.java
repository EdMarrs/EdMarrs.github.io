public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!"); // Display the string.
	      System.out.println("This is a Test!"); // Display the string.
        System.out.println("This is Working"); // Display the string.
    }
}
