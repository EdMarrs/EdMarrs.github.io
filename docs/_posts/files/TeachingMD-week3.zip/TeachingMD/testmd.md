# Ed's Programming Markdown Document



* [Part 1-JS](#javascript)
  - [Part 1.1-Date](#get-current-date)
  - [Part 1.2-Math](#do-math)
  - [Part 1.3-Arrays](#array)
* [Part 2-Imports](#import-tests)
  - [Part 2.1-Import JS](#import-js-test)
  - [Part 2.2-Import Tables](#import-chart-test)
  - [Part 2.3-Import Gif Test](#import-gif-test)
* [Part 3-Java](#java)
  - [Part 3.1-Print to Console](#print-to-console)
  - [Part 3.2-How Java Runs](#how-java-runs)
* [Part 4-Other WIP](#wip)
  - [Part 4.1-Entity Relationship Diagrams](#entity-relationship-diagrams)
  - [Part 4.2-GnuPlot](#gnuplot)



##Javascript
####Get Current Date
This is an example string of code to get the current date
```javascript {.line-numbers cmd="node"}
const date = new Date(Date.now());
console.log(date.toString());
```
<hr>
####Do Math
```javascript {.line-numbers cmd="node"}
var x = 456;
var y = 125;
var ans= x + y;
console.log(ans);

```
<hr>
####Array
```javascript {.line-numbers cmd="node"}
var myarr = [20,30,40,50,60,70];
var my_new_arr = myarr.slice(2,5);
console.log(myarr);
console.log(my_new_arr);
```
<hr>
#Import Tests
####Import JS Test
@import "test2.js" {code_block=true class="line-numbers"}
####Import Chart Test
@import "chart1.csv"
####Import Gif Test
@import "code.gif"
<hr>



#Java
###(Must Have .Java Class in folder)

####Print to Console
This is an example in java of printing "Hello World" to the console
@import "HelloWorld.java"
```java{.line-numbers cmd=true args=[HelloWorld.java]}
Run Code!
```
<hr>
###How Java Runs
```mermaid
graph TD;
    A[Our Java Code Sourcecode] -->|Compiler-Javac| B[Bytecode]
    B-->|Java Virtual Machine| C[Machine Code]
    C -->D[Program Runs]
```
<hr>
#WIP
## Testing Plots
####Entity Relationship Diagrams
```erd {cmd=true output="html" args=["-i", "$input_file" "-f", "png"]}

[Person]
*name
height
weight
+birth_location_id

[Location]
*id
city
state
country

Person *--1 Location
```
<hr>
####GnuPlot
```gnuplot {cmd=true output="html"}
set terminal svg
set title "Simple Plots" font ",20"
set key left box
set samples 50
set style data points

plot [-10:10] sin(x),atan(x),cos(atan(x))
```

<hr>
