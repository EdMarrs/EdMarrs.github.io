var x = 456;
var y = 125;
var ans= x + y;
console.log(ans);
