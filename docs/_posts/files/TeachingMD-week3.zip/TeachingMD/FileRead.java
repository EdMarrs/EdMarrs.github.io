import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileRead {
    public static void main(String[] args) throws IOException {
      BufferedReader br = new BufferedReader(new FileReader(args[0]));
      String line;
      while ((line = br.readLine()) != null) {

        System.out.println(highlight(line));
      }
      br.close();
    }
    private static String highlight(String text) {
    //Keywords
    String[] array = {
        "abstract", "assert", "boolean", "break", "byte", "case",
        "catch", "char", "class", "const", "continue", "default", "do",
        "double", "else", "enum", "extends", "false", "final", "finally", "float",
        "for", "goto", "if", "implements", "import", "instanceof", "int",
        "interface", "long", "native", "new", "null", "package", "private", "protected",
        "public", "return", "short", "static", "String", "strictfp", "super", "switch", "synchronized",
        "System", "this", "throw", "throws", "transient", "true", "try", "void", "volatile", "while"
    };

    //Highlight every keyword with color:#7f0055
    for(int i = 0; i < array.length; i++) {
      text = text.replaceAll(array[i] + "(?![a-zA-Z])", "<span style='color:#CF9FFF; font-weight:bold; '>" + array[i] + "</span>");

    }
    //Highlight Strings
    text = text.replaceAll("\"(?<render>.*?)\"", "<span style='color:#339999; font-weight:bold; '>" + "\"${render}\"" + "</span>");

    //Highlight import-statements
    text = text.replaceAll("import(?<render>.*?);", "<span style='color:#ffffbf; font-weight:bold; '>" + "import${render};" + "</span>");

    //Highlight single-line-comments
    text = text.replaceAll("//(?<render>.*?)$", "<span style='color:#98fb98; font-weight:bold; '>" + "//${render}" + "</span>");


    return text;
    }
  }
