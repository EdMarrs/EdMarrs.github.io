# Markdown Document

##Javascript
####Get Current Date
This is an example string of code to get the current date
```javascript {.line-numbers cmd="node"}
const date = new Date(Date.now());
console.log(date.toString());
```
<hr>
####Do Math
```javascript {.line-numbers cmd="node"}
var x = 456;
var y = 125;
var ans= x + y;
console.log(ans);

```
<hr>
####Array
```javascript {.line-numbers cmd="node"}
var myarr = [20,30,40,50,60,70];
var my_new_arr = myarr.slice(2,5);
console.log(myarr);
console.log(my_new_arr);
```

##Java
###(Must Have .Java Class in folder)
####Print to Console
This is an example in java of printing "Hello World" to the console.
```java{.line-numbers cmd=true args=[FileRead.java HelloWorld.java]}
Show Code!
```
```java{.line-numbers cmd=true args=[HelloWorld.java]}
Run Code!
```
###How Java Runs
```mermaid
graph TD;
    A[Our Java Code Sourcecode] -->|Compiler-Javac| B[Bytecode]
    B-->|Java Virtual Machine| C[Machine Code]
    C -->D[Program Runs]
```  



<hr>
